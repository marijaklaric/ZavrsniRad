-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2018 at 12:20 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beauty_centar`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `id_kategorije` int(11) NOT NULL,
  `naziv` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `aktivnost` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`id_kategorije`, `naziv`, `aktivnost`) VALUES
(1, 'Frizura', 1),
(8, 'Sminka', 1),
(10, 'Nokti', 1),
(11, 'Depilacija', 1);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id_korisnika` int(11) NOT NULL,
  `ime` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `e_mail` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lozinka` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `administrator` tinyint(1) NOT NULL,
  `aktivnost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnika`, `ime`, `prezime`, `e_mail`, `lozinka`, `administrator`, `aktivnost`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 'admin', 1, 1),
(3, 'Marija', 'Klaric', 'marija@gmail.com', 'marija', 1, 1),
(8, 'Nikolina', 'Nikolic', 'nikolina@gmail.com', 'nikolina', 0, 1),
(9, 'Sanja', 'Maric', 'sanja@gmail.com', 'sanja', 0, 1),
(10, 'Marijana', 'Omazic', 'marijana@gmail.com', 'marijana', 0, 1),
(11, 'Andjela', 'Bosnjak', 'andjela@gmail.com', 'andjela', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rezervacije`
--

CREATE TABLE `rezervacije` (
  `id_rezervacije` int(11) NOT NULL,
  `cijena` float NOT NULL,
  `id_usluge` int(11) NOT NULL,
  `id_korisnika` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rezervacije`
--

INSERT INTO `rezervacije` (`id_rezervacije`, `cijena`, `id_usluge`, `id_korisnika`) VALUES
(29, 50, 13, 11),
(30, 30, 18, 11),
(31, 35, 11, 11),
(32, 20, 21, 11),
(33, 25, 14, 11),
(34, 40, 15, 10),
(35, 0, 19, 10),
(36, 50, 13, 10),
(37, 15, 20, 9),
(38, 40, 15, 9),
(39, 25, 14, 9),
(40, 35, 11, 9);

-- --------------------------------------------------------

--
-- Table structure for table `usluga`
--

CREATE TABLE `usluga` (
  `id_usluge` int(11) NOT NULL,
  `id_korisnika` int(11) NOT NULL,
  `naziv` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `datum` date NOT NULL,
  `vrijeme` time NOT NULL,
  `br_termina` int(11) NOT NULL,
  `cijena` float NOT NULL,
  `id_kategorije` int(11) NOT NULL,
  `aktivnost` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usluga`
--

INSERT INTO `usluga` (`id_usluge`, `id_korisnika`, `naziv`, `datum`, `vrijeme`, `br_termina`, `cijena`, `id_kategorije`, `aktivnost`) VALUES
(9, 1, 'Sisanje', '2018-09-25', '12:00:00', 4, 15, 1, 1),
(11, 1, 'Farbanje', '2018-10-02', '12:30:00', 0, 35, 1, 1),
(13, 1, 'Sminka', '2018-10-01', '10:00:00', 4, 50, 1, 1),
(14, 1, 'Geliranje', '2018-10-03', '15:45:00', 5, 25, 1, 1),
(15, 1, 'Manikura', '2018-10-06', '08:00:00', 3, 40, 10, 1),
(16, 1, 'Frizura', '2018-10-04', '13:30:00', 5, 30, 1, 1),
(17, 1, 'Sminka', '2018-10-06', '16:00:00', 3, 35, 8, 1),
(18, 1, 'Pedikura', '2018-11-10', '17:00:00', 2, 30, 10, 1),
(19, 1, 'Slobodan izbor', '2018-11-10', '08:00:00', 1, 0, 11, 1),
(20, 1, 'Ruke', '2018-12-08', '09:45:00', 2, 15, 11, 1),
(21, 1, 'Trajni lak', '2018-12-28', '12:00:00', 9, 20, 10, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`id_kategorije`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id_korisnika`);

--
-- Indexes for table `rezervacije`
--
ALTER TABLE `rezervacije`
  ADD PRIMARY KEY (`id_rezervacije`),
  ADD KEY `id_usluge` (`id_usluge`),
  ADD KEY `FOREIGN KEY` (`id_korisnika`);

--
-- Indexes for table `usluga`
--
ALTER TABLE `usluga`
  ADD PRIMARY KEY (`id_usluge`),
  ADD KEY `id_kategorije` (`id_kategorije`),
  ADD KEY `usluga_ibfk_2` (`id_korisnika`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategorija`
--
ALTER TABLE `kategorija`
  MODIFY `id_kategorije` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id_korisnika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `rezervacije`
--
ALTER TABLE `rezervacije`
  MODIFY `id_rezervacije` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `usluga`
--
ALTER TABLE `usluga`
  MODIFY `id_usluge` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rezervacije`
--
ALTER TABLE `rezervacije`
  ADD CONSTRAINT `rezervacije_ibfk_1` FOREIGN KEY (`id_usluge`) REFERENCES `usluga` (`id_usluge`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rezervacije_ibfk_2` FOREIGN KEY (`id_korisnika`) REFERENCES `korisnik` (`id_korisnika`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usluga`
--
ALTER TABLE `usluga`
  ADD CONSTRAINT `usluga_ibfk_2` FOREIGN KEY (`id_korisnika`) REFERENCES `korisnik` (`id_korisnika`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usluga_ibfk_3` FOREIGN KEY (`id_kategorije`) REFERENCES `kategorija` (`id_kategorije`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
